package com.pizza.checker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
