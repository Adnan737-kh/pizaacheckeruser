import 'package:flutter/material.dart';

class BranchCategoryView extends StatelessWidget {
  final String type;
  const BranchCategoryView({Key? key, required this.type}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
