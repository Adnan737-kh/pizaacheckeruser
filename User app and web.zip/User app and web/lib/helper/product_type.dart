enum ProductType {
  latestProduct,
  popularProduct,
}