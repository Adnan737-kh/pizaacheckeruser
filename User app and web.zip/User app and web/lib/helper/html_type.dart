enum HtmlType {
  termsAndCondition,
  aboutUs,
  privacyPolicy,
  refundPolicy,
  cancellationPolicy,
  returnPolicy,
}