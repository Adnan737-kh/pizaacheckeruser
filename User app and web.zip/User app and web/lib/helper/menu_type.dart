enum MenuType {
  appLogo,
  appName,
  text,
  search,
  cart,
  menu
}